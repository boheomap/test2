/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "stdio.h"    /* Standard IO library: sprintf */
#include "timer.h"	/* software timber */
#include "switch.h"	/* switch */

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define setting		1
#define counting 	2
#define pause		3

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
int status = setting;
int time_change_stt = 0;
int second = 0;
int minute = 0;

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);
void display_current_time(void);

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	/* Local time structure to temporary store the global time */
	int count = 0, i =0 , a=0;
	int switch_number = 0;
	char time[6];
	/* Initialize user system */
	r_main_userinit();
	
	/* Clear LCD display */
	ClearLCD();
	
	DisplayLCD(LCD_LINE1, (uint8_t *)"Setting...");
	display_current_time();
	
	while (1) 
	{
		/* check if sw3 pressed and break before the delay counter equals 0 */
		if(i==0) switch_number = check_switch();
		switch(status){
			case counting: 	
				/* check if sw3 is press */
				if(3 == switch_number){
					DisplayLCD(LCD_LINE1, (uint8_t *)"Paused...");
					/* set i to normal to check switch again */
					i=0;
					/* set status */
					status = pause;
				}else {
					/* delay 1s */
					i = 1000;
					while(i){
						/* check switch every 10s */
						if((i % 10) == 0){
							switch_number = check_switch();
						}
						/* break the loop if sw3 is pressed */
						if((switch_number == 3)){	
							break;
						}
						/* wait function in assembly */
						Wait1MSecond();
						i--;
					}
					/* prevent decrease when pressing pause */
					if(switch_number != 3){
						second--;
						/* check if second 0 */
						if(second <= 0){
							second = 59;
							minute--;
						}
						/* check if minute 0 then reset */
						if(minute < 0){
							DisplayLCD(LCD_LINE1, (uint8_t *)"Setting...");
							status = setting;
							/* reset timer */
							second = 0;
							minute = 0;
						}
						display_current_time();
					}
				}
				break;
			case pause:	
				/* check if switch 3 is press when pausing state */
				if(3 == switch_number){
					/* resume counting */
					DisplayLCD(LCD_LINE1, (uint8_t *)"Counting...");
					status = counting;
				}
				/* check if switch 2 is press when pausing state */
				else if(2 == switch_number){
					/* reset the counter */
					DisplayLCD(LCD_LINE1, (uint8_t *)"Setting...");
					status = setting;
					/* reset timer */
					second = 0; 
					minute = 0; 
					display_current_time();
				}
				break;
			case setting:	
				/* check if switch 1 is press when setting state */
				if(1 == switch_number){
					second++;
					/* reset to 59 if second equals 60 */
					if(60 == second){
						second = 59;
					}
					display_current_time();
				}
				/* check if switch 2 is press when setting state */
				else if(2 == switch_number){
					minute++;
					/* reset to 59 if minute equals 60 */
					if(60 == minute){
						minute = 59;
					}
					display_current_time();
				}
				/* check if switch 3 is press when setting state */
				else if(3 == switch_number && (second != 0 || minute != 0)){
					DisplayLCD(LCD_LINE1, (uint8_t *)"Counting...");
					status = counting;
				}
				break;
			default:
				break;
		}
		/* delay 50ms */ 
		a = 10;
		while(a){
			Wait1MSecond();
			a--;
		} 
	}
}

/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)
{
	uint16_t i;

	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();
	
}

/******************************************************************************
* Function Name: display_current_time
* Description  : display current time
* Arguments    : none
* Return Value : none
******************************************************************************/
void display_current_time(){
	char cur_time[6];
	/* convert minute to char */
	cur_time[0] = (char)(minute / 10) + '0';
	cur_time[1] = (char)(minute % 10) + '0';
	cur_time[2] = ':';
	/* convert second to char */
	cur_time[3] = (char)(second / 10) + '0';
	cur_time[4] = (char)(second % 10) + '0';
	cur_time[5] = '\0';
	DisplayLCD(LCD_LINE2, (uint8_t *) cur_time);
}
/******************************************************************************
End of file
******************************************************************************/

