/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : intp.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "switch.h"     /* switch header */
#include "lcd.h"

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
int flagSW1 = 0;
int flagSW2 = 0;
int flagSW3 = 0;
int cur = 0;
int pre = 1;
int match_time;

/******************************************************************************
* Function Name: init_switch
* Description  : Initialize SW1,SW2,SW3
* Arguments    : none
* Return Value : none
******************************************************************************/
void init_switch()
{
	
}

/******************************************************************************
* Function Name: check_switch
* Description  : check switch which is pressed
* Arguments    : none
* Return Value : number of switch
******************************************************************************/
int check_switch()
{
	int switch_number;
	/* update priority of switch to use eliminate chattering function */
	if((0 == SW1) && (flagSW1 == 0)){
		/* set switch 1 to high priority */
		flagSW1 = 1;
		flagSW2 = 0;
		flagSW3 = 0;
	}
	else if((0 == SW2) && (flagSW2 == 0)){
		/* set switch 2 to high priority */
		flagSW1 = 0;
		flagSW2 = 1;
		flagSW3 = 0;
	}
	else if((0 == SW3) && (flagSW3 == 0)){
		/* set switch 3 to high priority */
		flagSW1 = 0;
		flagSW2 = 0;
		flagSW3 = 1;
	}
	/* switch has high priority can use eliminate chattering function */
	if(1 == flagSW1){
		/* apply chattering algorithm to switch 1 */
		if(eliminate_chattering(1)){
			flagSW1 = 0;
			flagSW2 = 0;
			flagSW3 = 0;
			/* return switch 1 */
			return 1;
		}
	}
	else if(1 == flagSW2){
		/* apply chattering algorithm to switch 1 */
		if(eliminate_chattering(2)){
			flagSW1 = 0;
			flagSW2 = 0;
			flagSW3 = 0;
			/* return switch 2 */
			return 2;
		}
	}
	else if(1 == flagSW3){
		/* apply chattering algorithm to switch 1 */
		if(eliminate_chattering(3)){
			flagSW1 = 0;
			flagSW2 = 0;
			flagSW3 = 0;
			/* return switch 1 */
			return 3;
		}
	}
	return 0;
}

/******************************************************************************
Private global variables and functions
******************************************************************************/

/******************************************************************************
* Function Name: eliminate_chattering
* Description  : eliminate_chattering
* Arguments    : none
* Return Value : none
******************************************************************************/
int eliminate_chattering(int switch_number)
{
	/* update the current pulse base on switch */
	switch(switch_number){
		case 1: 
			cur = SW1;
			break;
		case 2: 
			cur = SW2;
			break;
		case 3: 
			cur = SW3;
			break;
	}
	
	/* prevent increase over time when pressing the switch */
	if((-1 == match_time) && (pre == cur)){
		return 0;	
	}
	/* eliminate chattering algorithm */
	if((cur == 0) && (pre == 0)){
		match_time = match_time + 1;
		if(match_time >= 3){
			/* to check if the checking finished */
			match_time = -1;
			return 1;
		}
	}else{
		match_time = 0;
		pre = cur;
	}
	return 0;
}

/******************************************************************************
* Function Name: display switch flag
* Description  : display switch flag for testing purpose
* Arguments    : none
* Return Value : none
******************************************************************************/
void display_flag(){
	char dsw1[2];
	char dsw2[2];
	char dsw3[2];
	/* convert flag 1 to char */
	dsw1[0] = (char)flagSW1 + '0';
	dsw1[1] = '\0';
	DisplayLCD(LCD_LINE3, (uint8_t *) dsw1);
	
	/* convert flag 2 to char */
	dsw2[0] = (char)flagSW2 + '0';
	dsw2[1] = '\0';
	DisplayLCD(LCD_LINE4, (uint8_t *) dsw2);
	
	/* convert flag 3 to char */
	dsw3[0] = (char)flagSW3 + '0';
	dsw3[1] = '\0';
	DisplayLCD(LCD_LINE5, (uint8_t *) dsw3);
	
}
/******************************************************************************
End of file
******************************************************************************/
